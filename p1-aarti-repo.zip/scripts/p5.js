// Teachable Machine
// The Coding Train / Daniel Shiffman
// https://thecodingtrain.com/TeachableMachine/1-teachable-machine.html
// https://editor.p5js.org/codingtrain/sketches/PoZXqbu4v

// The video
let video;
// For displaying the label
let label = "waiting...";
// The classifier
let classifier;
let modelURL = 'https://teachablemachine.withgoogle.com/models/bmz_Bg8rV/';

// STEP 1: Load the model!
function preload() {
  classifier = ml5.soundClassifier(modelURL + 'model.json');
}


function setup() {
  createCanvas(720, 400);
background(250,250,100);

  // STEP 2: Start classifying
  classifyAudio();
}

// STEP 2 classify the videeo!
function classifyAudio() {
  classifier.classify(gotResults);
}

var x = 0;
var speed = 20;

var spot = {
  x: 100,
  y: 50
};

var col = {
  r: 255,
  g: 0,
  b: 0
};

function draw() {
  //background(250,250,100);



  // STEP 4: Draw the label
  textSize(32);
  textAlign(CENTER, CENTER);
  fill(255);
  //text(label, width / 2, height - 16);

  // Pick an emoji, the "default" is an empty string
  let emoji = "";
   
  if (label == "A(4th)") {
    //oji = "🌈";
    emoji = "";
  stroke(78);
  strokeWeight(1);
  fill(57,100,91);
  ellipse(100,x , 80, 80,25);

  if (x > width) {
    speed = -7;
  }
    x = x + speed;
   //ckground(220);
  } else if (label == "A(5th)") {
 // emoji = "🦄";
   noStroke();
  //strokeWeight(4);
  fill(57,100,91);
  ellipse(x,100 , 100, 100);

  if (x > width) {
    speed = -7;
  }
    x = x + speed;
  } else if (label == "B(4th)") {
  //emoji = "🎸";
    col.r = random(200, 250);
  col.g = 0;
  col.b = random(200, 250);

  spot.x = random(0, width);
  spot.y = random(0, height);
  noStroke();
  fill(col.r, col.g, col.b, 80);
  rect(spot.x, spot.y, 24, 24);
  }else if (label == "B(5th)") {
  //emoji = "🎸";
    col.r = random(100, 255);
  col.g = 0;
  col.b = random(100, 190);

  spot.x = random(0, width);
  spot.y = random(0, height);
  noStroke();
  fill(col.r, col.g, col.b, 80);
  ellipse(spot.x, spot.y, 24, 24);
  }else if (label == "C(4th)") {
  //emoji = "🎸";
    // A design for a simple flower
    fill('lightpink');
    stroke(127, 63, 120);
  translate(580, 200);
  noStroke();
  for (let i = 0; i < 10; i ++) {
    ellipse(0, 30, 20, 80);
    rotate(PI/5);
  }
  }else if (label == "C(5th)") {
  //emoji = "🎸";
    col.r = random(100, 255);
  col.g = random(100, 190);
  col.b = 0;

  spot.x = random(0, width);
  spot.y = random(0, height);
  noStroke();
  fill(col.r, col.g, col.b, 80);
  rect(spot.x, spot.y, 24, 24);
  }else if (label == "D(4th)") {
 // emoji = "🎸";
   noStroke();
  //strokeWeight(4);
  fill(12,90,74,20);
  ellipse(100, x, 100, 100);

  if (x > width) {
    speed = -7;
  }
    x = x + speed;
  }else if (label == "E(4th)") {
 // emoji = "🎸";
    noStroke();
  //strokeWeight(4);
  fill(300,24,80,20);
  ellipse(60, x, 100, 100);

  if (x > width) {
    speed = -7;
  }
    x = x + speed;
  }else if (label == "F(4th)") {
  //emoji = "🎸";
    noStroke();
  //strokeWeight(4);
  fill(276,100,85);
  ellipse(x,100 , 100, 100);

  if (x > width) {
    speed = -5;
  }
    x = x + speed;
  }else if (label == "G(4th)") {
  //emoji = "🎸";
    fill('lightgreen');
    stroke(127, 63, 120);
  translate(100, 240);
  noStroke();
  for (let i = 0; i < 10; i ++) {
    ellipse(0, 30, 20, 80);
    rotate(PI/5);
  }
  }else if (label == "Background noise") {
    //emoji = "🎸";
    emoji = ''
    /*
    stroke(255);
strokeWeight(4);
fill(14,78,62);
ellipse(x, 500, 80, 80);

if (x > width) {
  speed = -7;
}
  x = x + speed;
  */
  background(250,250,100,200);
  }


  // Draw the emoji
  textSize(256);
  //text(emoji, width / 2, height / 2);
}

// STEP 3: Get the classification!
function gotResults(error, results) {
  // Something went wrong!
  if (error) {
    console.error(error);
    return;
  }
  // Store the label and classify again!
  label = results[0].label;

}
