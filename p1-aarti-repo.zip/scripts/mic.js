// Adapted from MDN "Voice-change-o-matic" @ https://github.com/mdn/voice-change-o-matic

function listenForFreqAndVol() {
    const freqContainer = $("#freq-container");
    const volContainer = $("#vol-container");

    var audioContext = new(window.AudioContext || window.webkitAudioContext)(); // cross-browser
    var microphone;

    var analyser = audioContext.createAnalyser();

    //main block for doing the audio recording
    if (navigator.mediaDevices.getUserMedia) {
        console.log('getUserMedia supported.');
        var constraints = { audio: true } // ask for audio media, not video
        navigator.mediaDevices.getUserMedia(constraints)
            .then(
                function(stream) {
                    microphone = audioContext.createMediaStreamSource(stream); // source node = microphone
                    microphone.connect(analyser); // connect microphone node to analyser node
                    //analyser.connect(audioContext.destination); // connect analyser node to destination aka speakers. omit this line for no output
                    beginRecording();
                })
            .catch(function(err) { console.log('The following error occured: ' + err); })
    } else {
        console.log('getUserMedia not supported on your browser!');
    }

    function beginRecording() {
        console.log("Begin recording")
        analyser.fftSize = 512; // NumOfSamples of audio to perform FFT on
        var bufferLength = analyser.fftSize;
        //var timeDomainDataArray = new Uint8Array(bufferLength);
        var freqBinDataArray = new Uint8Array(bufferLength);

        var checkAudio = function() {
            //analyser.getByteTimeDomainData(timeDomainDataArray);
            analyser.getByteFrequencyData(freqBinDataArray);
            freqContainer.html("Freq = " + getIndexOfMax(freqBinDataArray));
            volContainer.html("Volume = " + getRMS(freqBinDataArray));

            //console.log(getRMS(freqBinDataArray));
            //console.log(getIndexOfMax(freqBinDataArray));
        };

        setInterval(checkAudio, 64); // runs the checkAudio function every 64ms
    }
    // Root-Mean-Square calculation over frequency to get average volume
    function getRMS(spectrum) {
        var rms = 0;
        for (var i = 0; i < spectrum.length; i++) {
            rms += spectrum[i] * spectrum[i];
        }
        rms /= spectrum.length;
        rms = Math.sqrt(rms);
        return rms;
    }

    function getIndexOfMax(array) {
        return array.reduce((iMax, x, i, arr) => x > arr[iMax] ? i : iMax, 0);
    }
}